@php $i=1 @endphp
@foreach($invoice as $row)
    <tr>
        <td> {{ $i++ }} </td>
        <td> {{ $row->income_head }} <input type="hidden" id="in_{{$row->id}}" name="bill_received[]" value="{{$row->id}}"> </td>
        <td> {{ $row->month }} </td>
        <td> {{ $row->amount }} </td>
        <td id="rd_{{$row->id}}">  {{ $row->amount -  $row->payment_amount}}  </td>
        <td>  <input type="text" id="in_{{$row->id}}" name="bill_received_amount[]" onblur="checkAmount(this.value,{{$row->id}})"  onkeypress="return filterKeyNumber(this,event,'r_{{$row->id}}')">
            <p id="r_{{$row->id}}" style="display: none;color: red; margin-top: -11px; text-align: left;">  Please Enter Number Only</p></td>
    </tr>
@endforeach
