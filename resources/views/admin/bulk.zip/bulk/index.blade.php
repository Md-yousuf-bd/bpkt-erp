@extends('admin.layouts.app')

@section('uncommonExCss')
    @include('admin.layouts.commons.dataTableCss')
@endsection

@section('content')
    <div class="container-fluid">
        <div class="row">
            <div class="col-lg-12 ">
                <div class="card">
                    <div class="card-header">
                        <h5 class="card-title">Bulk Info List</h5>
                        <div class="card-tools">
                            @if(auth()->user()->can('create-bulk'))
                                <a href="{{route('bulk.create')}}" class="btn btn-sm btn-outline-primary pull-right"><span class="fa fa-plus-circle"></span> Add Bulk Info</a>
                            @endif
                        </div>
                    </div>
                    <div class="card-body">
                        <div class="table-responsive" style="font-size: 13px; background: white; padding: 10px;  overflow: auto;">
                            <table id="bulkTbl" class="table table-bordered table-hover table-striped" style="font-size: 14px; width:100%;">
                                <thead>
                                <tr>
                                    <th style="width: 3%;">S.L.</th>
{{--                                    <th style="width: 260px !important;" >Action</th>--}}
                                    <th>Billing Id</th>
                                    <th>Shop No</th>
                                    <th>Shop Name</th>
                                    <th>Invoice No</th>
                                    <th>created by</th>
                                    <th >@lang('commons/table_header.Last Updated At')</th>
                                </tr>
                                </thead>
                                <tbody>

                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- .content -->

@endsection

@section('uncommonExJs')
    @include('admin.layouts.commons.dataTableJs')
@endsection

@section('uncommonInJs')
    <script>
        var userTableColumnNames=[];
        (function() {
            "use strict";
            listView({data:{},_token: "{{csrf_token()}}"});
            $('#bulkTbl')
                .on( 'error.dt', function ( e, settings, techNote, message ) {
                    console.log( 'An error has been reported by DataTables: ', message );
                } )
                .DataTable();
        })(jQuery);



        function listView(data) {
            console.log(data);
            $('#bulkTbl').DataTable({
                "processing": true,
                "serverSide": true,
                // destroy: true,
                "searching": true,
                fixedHeader: true,
                "ajax":{
                    "url": '{!! route('bulk.list') !!}',
                    "dataType": "json",
                    "type": "POST",
                    "data": data,
                    "error": function (xhr, error, code) {
                        console.log(xhr.status);
                        if(xhr.status==500){
                            alert("Sorry! Can not Process it");
                        }
                        console.log(error);
                        console.log(code);
                        // ShowDataTable(null);
                    }
                },
                "sScrollY" : "400",
                "sScrollX" : true,
                oLanguage: {sProcessing: "<div  id='loader' style='background: black;padding:10px;color:#fff; font-size:15px;z-index: 5999999 !important;' > Loading.... </div>"},
                "columns": [
                    {data:'sl',name:'sl'},
                    // {data:'action',name:'action',searchable: false, orderable: false},
                    {data:'id',name:'id'},
                    {data:'shop_no',name:'shop_no'},
                    {data:'shop_name',name:'shop_name'},
                    {data:'invoice_no',name:'invoice_no'},
                    {data:'created_by',name:'created_by'},
                    {data:'updated_at',name:'updated_at'}
                ],
                "dom": 'lBfrtip',

                buttons: [
                    'excel',
                    'csv',
                    'pdf',
                    'print'
                ],

                scrollX: true,
            });
        }

    </script>

@endsection
