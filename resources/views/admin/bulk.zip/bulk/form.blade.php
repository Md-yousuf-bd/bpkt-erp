<?php  $i=1 ; $bill_amount = 0; $due_amount=0;$moth=0; ?>

<table id="assetInfo" class="table table-bordered table-hover table-striped" style="font-size: 14px; width:100%;">
    <thead>
    <tr>
        <td style="width: 3%;">S.L.</td>
        <td style="text-align: center;">Select all <br></br>
        <input type="checkbox" id="checkAllss"  onchange="Bulk.checkAllnput()" checked>
        </td>
        <td >Asset No</td>
        <td>Tenant Name</td>
        <td>Area (Sft)</td>
        <td>Rate/Sft</td>
        <td>Total Amount</td>
        <td>VAT</td>
        <td>Total Bill</td>

    </tr>
    </thead>
    <tbody>


@foreach($customer as $row)
    <tr>
        <?php
        $bill_amount = $bill_amount+ $row->amount ;
$due_amount +=($row->amount -  $row->payment_amount); $moth =  $row->month

        ?>

        <td> {{ $i++ }} </td>
         <td style="text-align: center"> <input class="checkIs" checked type="checkbox" name="chk[]" value="{{ $row->asset_no }}"> </td>
        <td> {{ $row->asset_no }} <input type="hidden"  name="asset_no[]" value="{{$row->asset_no}}"> </td>
        <td> {{ $row->shop_name }} <input type="hidden"  name="customer_name[]" value="{{$row->shop_name}}">
            <input type="hidden"  name="customer_id[]" value="{{$row->id}}"> </td>
        <td> {{ $row->area }} <input type="hidden"  name="area[]" value="{{$row->area}}">  </td>
            @if($type==29)
                <td> {{ $rent->rate }}  <input type="hidden"  name="rate[]" value="{{$rent->rate}}">
                </td>
                <td style="text-align: right"> {{ number_format($rent->rate*$row->area,2) }}
                    <input type="hidden"  name="amount[]" value="{{$rent->rate*$row->area}}"> </td>
                <td>
                    @php $vat = 0; @endphp
                @if($row->vat_exemption=='No')
                    @php
                        $vat = $rent->rate*$row->area*.15;
                    @endphp
                    {{$vat}}
                    @endif
                    <input type="hidden"  name="vat[]" value="{{$vat}}">
                </td>
                <td style="text-align: right"> {{ number_format(($rent->rate*$row->area)+$vat,2) }}
                    <input type="hidden"  name="total[]" value="{{round(($rent->rate*$row->area)+$vat,2)}}">
                </td>
                @elseif($type==31)
                <td> {{ $service->rate }}  <input type="hidden"  name="rate[]" value="{{$service->rate}}">
                </td>
                <td style="text-align: right"> {{ number_format($service->rate*$row->area,2) }}
                    <input type="hidden"  name="amount[]" value="{{$service->rate*$row->area}}"> </td>
                <td>
                    @php $vat = 0; @endphp
                    @if($row->vat_exemption=='No')
                        @php
                            $vat = $service->rate*$row->area*.15;
                        @endphp
                        {{$vat}}
                    @endif
                    <input type="hidden"  name="vat[]" value="{{$vat}}">
                </td>
                <td style="text-align: right"> {{ number_format(($service->rate*$row->area)+$vat,2) }}
                    <input type="hidden"  name="total[]" value="{{round(($service->rate*$row->area)+$vat,2)}}">
                </td>
                @elseif($type==33)
            @elseif($type==34)
                @endif

    </tr>
@endforeach
    </tbody>
</table>


{{--<tr>--}}
{{--    <?php--}}
{{--    $bill_amount = $bill_amount + $vat->vat_amount ;--}}
{{--    $due_amount = $due_amount + ($vat->vat_amount - $vat->vat_total_paid) ;--}}
{{--    ?>--}}
{{--    <td colspan="3"><strong></strong></td>--}}
{{--    <td ><strong>{{$bill_amount}}</strong></td>--}}
{{--    <td> <strong>{{$due_amount}}</strong> </td>--}}
{{--    <td> <strong> <span id="sp_total"> 0 </span></strong> </td>--}}
{{--</tr>--}}
