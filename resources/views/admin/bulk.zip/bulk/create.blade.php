@extends('admin.layouts.app')

@section('uncommonExCss')
    <link rel="stylesheet" type="text/css" href="{{asset('bower/pikaday/pikaday.css')}}">
@endsection

@section('content')
    <div class="container-fluid">
        <div class="row">
            <div class="col-lg-10 col-md-10 col-sm-12 col-xs-12 mx-auto">
                <div class="card">
                    <div class="card-header">
                        <h5 class="card-title">Add Asset Info</h5>
                        <div class="card-tools">
                        </div>
                    </div>
                    <form id="addBulk" action="{{route('bulk.store')}}" method="post" class="">
                        <div class="card-body card-block">
                            {{ csrf_field() }}
                            <div class="row">
                                <div class="form-group col-lg-6 col-md-6 col-sm-12 col-xs-12">
                                    <label class="form-control-label">Receivable Date</label>
                                    <input type="text" id="journal_date" name="journal_date"  class="form-control" required="required">
                                </div>
                                <div class="form-group col-lg-6 col-md-6 col-sm-12 col-xs-12">
                                    <label for="fine_applicable">Is fine applicable</label>
                                    <select class="form-control select2" name="fine_applicable" id="fine_applicable">
                                        <option value="No">No</option>
                                        <option value="Yes">Yes</option>

                                    </select>

                                </div>

                        </div>
                            <div class="row">
                                <div class="form-group col-lg-6 col-md-6 col-sm-12 col-xs-12">
                                    <label class="form-control-label">Type</label>
                                    <select class="form-control select2" name="type" id="type">
                                        <option value="">None</option>
                                        <option value="Shop">Shop</option>
                                        <option value="Office">Office</option>

                                    </select>
                                </div>
                                <div class="form-group col-lg-6 col-md-6 col-sm-12 col-xs-12">
                                    <label class="form-control-label">Due Date</label>
                                    <input type="text" id="due_date" name="due_date"  class="form-control" >
                                </div>

                            </div>
                            <div class="row">

                                <div class="form-group col-lg-6 col-md-6 col-sm-12 col-xs-12">
                                    <label for="owner_id">Owner Name</label>
                                    <select class="form-control select2" name="owner_id" id="owner_id">
                                        <option value="">None</option>
                                        @foreach($owner as $row)
                                            <option value="{{$row->id}}">{{$row->name}}</option>
                                        @endforeach
                                    </select>

                                </div>
                                <div class="form-group col-lg-6 col-md-6 col-sm-12 col-xs-12">
                                    <label for="status">Billing Period</label>
                                    @php
                                        $month = ["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"];
                                        $year = date('Y');
                                    @endphp
                                    <select class="form-control select2" name="month" id="month" >
                                        <option value="0">None</option>
                                        @foreach($month as $row)
                                            <option value="{{$row.' '.$year}}">{{$row.' '.$year}}</option>
                                        @endforeach
                                    </select>

                                </div>


                            </div>
                            <div class="row">
                                <div  class="form-group col-lg-6 col-md-6 col-sm-12 col-xs-12">
                                    <label for="type">Category</label>
                                    <input type="hidden" name="name" id="name">
                                    <select class="form-control select2" name="category" id="category">
                                        <option value="29">Rent</option>
                                        <option value="31">Service Charge</option>
                                        <option value="33">Electricity</option>
                                        <option value="34">Food Court SC</option>
                                    </select>
                                </div>
                            </div>
                            <br>
                        <div class="card-footer">
                            <div class="row">
                                <div class="form-group col-lg-12 col-md-12 col-sm-12 col-xs-12">
                                    <button onclick="Bulk.ShowList();" type="button" class="btn btn-sm btn-success float-right">Show all active Users</button>
                                    <button onclick="Bulk.SubmitValue();" id="btnBSubmit" type="button" class="btn btn-sm btn-warning float-right">Create All Invoices</button>
                                </div>
                            </div>
                        </div>
                            <div id="listCustomer">
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>


@endsection

@section('uncommonExJs')
    <script src="{{asset('bower/pikaday/pikaday.js')}}"></script>
@endsection

@section('uncommonInJs')
    <script>
        (function() {
            jqueryCalendar('journal_date');
            jqueryCalendar('due_date');

        })(jQuery);

        function resetForm(id,header,body,okMessage='From reset successful.',cancelMessage=null) {
            alertify.confirm('<strong>'+header+'</strong>',body,
                function(){
                    document.getElementById(id).reset();
                    if(okMessage){
                        alertify.success(okMessage);
                    }
                },
                function(){
                    if(cancelMessage){
                        alertify.success(cancelMessage);
                    }
                });
        }
        let Bulk = function (){
            let ShowList = function () {
                $(".preloader").show();
                let type =$("#category").val()

                $.ajax({
                    type: 'GET',
                    url: 'show-all-customer/'+type,
                    dataType: 'json',
                    success: function (data) {
                        $(".preloader").hide();
                        // console.log(data);
                        $("#listCustomer").html(data.html);


                    },error:function(){
                        console.log(data);
                    }
                });
            }
            let SubmitValue = function (){
                $("#btnBSubmit").attr('type', 'submit');
            }
            let checkAllnput = function (){

                    if ($("#checkAllss").is(':checked')) {

                        $('.checkIs').prop('checked',true);


                    } else {
                        $('.checkIs').prop('checked',false);
                    }

            }
            return {
                ShowList: ShowList,
                SubmitValue: SubmitValue,
                checkAllnput: checkAllnput,

            }

        }();


    </script>
@endsection
